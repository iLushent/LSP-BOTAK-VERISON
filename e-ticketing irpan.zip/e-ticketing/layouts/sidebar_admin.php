<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/e-ticketing/assets/style/sidebar_admin.css">
    <link rel="stylesheet" href="/e-ticketing/assets/sweet-alert/css/bootstrap.min.css">
    <link rel="stylesheet" href="/e-ticketing/assets/sweet-alert/css/sweetalert.css">
    <!-- <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet"> -->
    <title></title>
</head>
<body>
    
    <div class="sidebar-admin" id="side_nav">
        <h2 class="text-lg font-semibold mb-4">Admin Panel</h2>

        <a href="/e-ticketing/admin/index.php" class="<?php if($page == "Dashboard") echo "active" ?> block p-2 rounded hover:bg-gray-700">Dashboard</a>
        <a href="/e-ticketing/admin/pengguna/" class="<?php if($page == "Data Pengguna") echo "active" ?> block p-2 rounded hover:bg-gray-700">Data Pengguna</a>
        <a href="/e-ticketing/admin/maskapai/" class="<?php if($page == "Data Maskapai") echo "active" ?> block p-2 rounded hover:bg-gray-700">Data Maskapai</a>
        <a href="/e-ticketing/admin/kota/" class="<?php if($page == "Data Kota") echo "active" ?> block p-2 rounded hover:bg-gray-700">Data Kota</a>
        <a href="/e-ticketing/admin/rute/" class="<?php if($page == "Data Rute") echo "active" ?> block p-2 rounded hover:bg-gray-700">Data Rute</a>
        <a href="/e-ticketing/admin/jadwal/" class="<?php if($page == "Data Jadwal Penerbangan") echo "active" ?> block p-2 rounded hover:bg-gray-700">Data Jadwal Penerbangan</a>
        <a href="/e-ticketing/admin/order/" class="<?php if($page == "Pemesanan Tiket") echo "active" ?> block p-2 rounded hover:bg-gray-700">Pemesanan Tiket</a>
        <a href="/e-ticketing/logout.php" onClick="return confirm('Apakah anda yakin ingin logout?')" class="logout">Logout</a>
    </div>
    
    <script src="/e-ticketing/assets/sweet-alert/js/jquery-2.1.4.min.js"></script>
    <script src="/e-ticketing/assets/sweet-alert/js/sweetalert.min.js"></script>
</body>
</html>