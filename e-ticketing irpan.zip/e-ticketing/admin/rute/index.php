<?php

$page = "Data Rute";

session_start();
require 'functions.php';

if(!isset($_SESSION["username"])){
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu, ya!');
        window.location = '../../auth/login/index.php';
    </script>
    ";
}

$rute = query("SELECT * FROM rute INNER JOIN maskapai ON maskapai.id_maskapai = rute.id_maskapai ORDER BY rute_asal");


?>

<?php require '../../layouts/sidebar_admin.php'; ?>

<style>
    body{
        background: #eee;
    }
    .container-rute{
        background: #fff;
        padding: 10px;
        border-radius: 5px;
        margin: 25px auto;
        margin-left: 280px;
        width: 75%;
    }
</style>

    <div class="container-rute">
        <h1 class="text-2xl font-semibold mb-2">Data Rute Penerbangan</h1>
        <a href="tambah.php" class="btn btn-primary mb-2">Tambah</a>

            <table class="table table-striped">
            <thead class="text-center">
                <tr>
                    <th class="px-2 py-2">No</th>
                    <th class="px-2 py-2">Nama Maskapai</th>
                    <th class="px-2 py-2">Rute Asal</th>
                    <th class="px-2 py-2">Rute Tujuan</th>
                    <th class="px-2 py-2">Tanggal Pergi</th>
                    <th class="px-2 py-2">Aksi</th>
                </tr>
            </thead>
            <tbody class="text-center">
                <?php $no = 1; ?>
                <?php foreach($rute as $data) : ?>
                <tr>
                    <td class="px-2 py-2"><?= $no; ?></td>
                    <td class="px-2 py-2"><?= $data["nama_maskapai"]; ?></td>
                    <td class="px-2 py-2"><?= $data["rute_asal"]; ?></td>
                    <td class="px-2 py-2"><?= $data["rute_tujuan"]; ?></td>
                    <td class="px-2 py-2"><?= $data["tanggal_pergi"]; ?></td>
                    <td class="px-2 py-2">
                        <a href="edit.php?id=<?= $data["id_rute"]; ?>"class="btn btn-success">Edit</a>
                        <a href="hapus.php?id=<?= $data["id_rute"]; ?>" class="btn btn-danger">Delete</a>
                    </td>
                </tr>
                <?php $no++; ?>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>