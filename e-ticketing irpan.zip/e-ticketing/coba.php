<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Sidebar</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        /* Custom styles */
        .sidebar {
            width: 280px;
        }
    </style>
</head>
<body class="bg-zinc-400">
    <!-- Sidebar -->
    <div class="flex h-screen bg-gray-400 text-gray-100">
        <div class="sidebar bg-gray-800 p-4">
            <h2 class="text-lg font-semibold mb-4">Admin Panel</h2>
            <ul>
                <li class="mb-2"><a href="#" class="block p-2 rounded hover:bg-gray-700">Dashboard</a></li>
                <li class="mb-2"><a href="#" class="block p-2 rounded hover:bg-gray-700">Users</a></li>
                <li class="mb-2"><a href="#" class="block p-2 rounded hover:bg-gray-700">Products</a></li>
                <li class="mb-2"><a href="#" class="block p-2 rounded hover:bg-gray-700">Orders</a></li>
                <li class="mb-2"><a href="#" class="block p-2 rounded hover:bg-gray-700">Settings</a></li>
            </ul>
        </div>
        <!-- Page Content -->
        <div class="flex-1 p-4">
            <h1 class="text-2xl font-semibold mb-4">Welcome to Admin Panel</h1>
                <table class="min-w-full border rounded-lg overflow-hidden">
                <thead class="bg-gray-800 text-white">
                    <tr>
                        <th class="w-1/4 py-2 px-4">ID</th>
                        <th class="w-1/4 py-2 px-4">Name</th>
                        <th class="w-1/4 py-2 px-4">Price</th>
                        <th class="w-1/4 py-2 px-4">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-gray-600 text-center">
                    <tr>
                        <td class="py-2 px-4">1</td>
                        <td class="py-2 px-4">Product A</td>
                        <td class="py-2 px-4">$10.00</td>
                        <td class="py-2 px-4">
                            <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-1 px-2 rounded">
                                Edit
                            </button>
                            <button class="bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-2 rounded">
                                Delete
                            </button>
                        </td>
                    </tr>
                    <tr>
                        <td class="py-2 px-4">2</td>
                        <td class="py-2 px-4">Product B</td>
                        <td class="py-2 px-4">$20.00</td>
                        <td class="py-2 px-4">
                            <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-1 px-2 rounded">
                                Edit
                            </button>
                            <button class="bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-2 rounded">
                                Delete
                            </button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>